package com.cjc.ims.seviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cjc.ims.app.model.Batch;
import com.cjc.ims.app.model.Course;
import com.cjc.ims.app.model.Faculty;
import com.cjc.ims.app.model.Student;
import com.cjc.ims.app.service.CJC;

public class Karvenagar implements CJC {

	Scanner sc = new Scanner(System.in);

	List<Course> courses = new ArrayList<Course>();
	List<Faculty> faculties = new ArrayList<Faculty>();
	List<Batch> batches = new ArrayList<Batch>();
	List<Student> students = new ArrayList<Student>();

	@Override
	public void addCourse() {
		System.out.println("===== Add Course =====");
		Course c = new Course();
		System.out.println("Enter Course Id:");
		c.setCid(sc.nextInt());
		System.out.println("Enter Course Name:");
		c.setCourseName(sc.next());
		courses.add(c);
		System.out.println("Course Added Successfully!\n");
	}

	@Override
	public void viewCourse() {
		System.out.println("===== View Courses =====");
		for (Course c : courses) {
			System.out.println("Course Id: " + c.getCid());
			System.out.println("Course Name: " + c.getCourseName());
			System.out.println("----------------------------");
		}
	}

	@Override
	public void addFaculty() {
		System.out.println("===== Add Faculty =====");
		Faculty f = new Faculty();
		System.out.println("Enter Faculty Id:");
		f.setFid(sc.nextInt());
		System.out.println("Enter Faculty Name:");
		f.setFacultyName(sc.next());
		
		viewCourse();
		System.out.println("Assign Course to Faculty");
		System.out.println("Select Course Id:");
		int cid = sc.nextInt();

		for (Course c : courses) {
			if (c.getCid() == cid) {
				f.setCourses(c);
				faculties.add(f);
				System.out.println("Faculty Added Successfully!");
				break;
			}
		}
		System.out.println();
	}

	@Override
	public void viewFaculty() {
		System.out.println("===== View Faculties =====");
		for (Faculty f : faculties) {
			System.out.println("Faculty Id: " + f.getFid());
			System.out.println("Faculty Name: " + f.getFacultyName());
			System.out.println("Course Id: " + f.getCourses().getCid());
			System.out.println("Course Name: " + f.getCourses().getCourseName());
			System.out.println("----------------------------");
		}
	}

	@Override
	public void addBatch() {
		System.out.println("===== Add Batch =====");
		Batch b = new Batch();
		System.out.println("Enter Batch Id:");
		b.setbId(sc.nextInt());
		System.out.println("Enter Batch Name:");
		b.setBatchName(sc.next());

		viewFaculty();
		System.out.println("Assign Faculty to Batch");
		System.out.println("Select Faculty Id:");
		int fid = sc.nextInt();

		for (Faculty f : faculties) {
			if (f.getFid() == fid) {
				b.setFaculty(f);
				batches.add(b);
				System.out.println("Batch Added Successfully!");
				break;
			}
		}
		System.out.println();
	}

	@Override
	public void viewBatch() {
		System.out.println("===== View Batches =====");
		for (Batch b : batches) {
			System.out.println("Batch Id: " + b.getbId());
			System.out.println("Batch Name: " + b.getBatchName());
			System.out.println("Faculty Id: " + b.getFaculty().getFid());
			System.out.println("Faculty Name: " + b.getFaculty().getFacultyName());
			System.out.println("----------------------------");
		}
	}

	@Override
	public void addStudent() {
		System.out.println("===== Add Student =====");
		Student s = new Student();
		System.out.println("Enter Student Id:");
		s.setsId(sc.nextInt());
		System.out.println("Enter Student Name:");
		s.setStudentName(sc.next());

		viewBatch();
		System.out.println("Assign Batch to Student");
		System.out.println("Select Batch Id:");
		int bid = sc.nextInt();

		for (Batch b : batches) {
			if (b.getbId() == bid) {
				s.setBatch(b);
				students.add(s);
				System.out.println("Student Added Successfully!");
				break;
			}
		}
		System.out.println();
	}

	@Override
	public void viewStudent() {
		System.out.println("===== View Students =====");
		for (Student s : students) {
			System.out.println("Student Id: " + s.getsId());
			System.out.println("Student Name: " + s.getStudentName());
			System.out.println("Batch Id: " + s.getBatch().getbId());
			System.out.println("Batch Name: " + s.getBatch().getBatchName());
			System.out.println("Faculty Id: " + s.getBatch().getFaculty().getFid());
			System.out.println("Faculty Name: " + s.getBatch().getFaculty().getFacultyName());
			System.out.println("----------------------------");
		}
	}
}
